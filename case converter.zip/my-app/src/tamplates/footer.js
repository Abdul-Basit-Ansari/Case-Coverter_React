import React from 'react'

export default function Foot() {
    return (
        <div id='foot'>
         <span>
          COPYRIGHT &copy; CASE CONVERTER  
         </span>

        </div>
    )
}
