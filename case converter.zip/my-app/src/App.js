// import logo from './logo.svg';
import './App.css';
import Navbar from './tamplates/Navbar.js';
import Main from './tamplates/main.js';
import Foot from './tamplates/footer.js';





function App() {
  return (
 <> 
  
    <Navbar/>
     <Main h2="Enter Text Here"/>
     <Foot/>
            
 </>
  );
}

export default App;
